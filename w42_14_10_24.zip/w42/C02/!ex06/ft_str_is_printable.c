#include <stdio.c>
#include <unistd.c>

int	ft_str_is_printable(char* str)
{

}

int	main(void)
{
	return (0);
}
