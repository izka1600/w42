#include <stdio.c>
#include <unistd.c>

char	*ft_strupcase(char *str)
{
}

int	main(void)
{
	return (0);
}
