/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ft.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ikoszela <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/14 21:02:13 by ikoszela          #+#    #+#             */
/*   Updated: 2024/10/14 21:02:18 by ikoszela         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <unistd.h>
//#include <stdio.h>
void	ft_ft(int *nbr)
{
	*nbr = 42;
}
/*
int	main(void)
{
	int	intiger;

	intiger = 38;
	printf("%i\n", intiger);
	ft_ft(&intiger);
	printf("%i\n", intiger);
	return ('0');
}
*/
