# w42
C programming
